
import SwiftUI
import Combine

struct ContentView : View {
    @State var apiManager = APIManager()
    var body: some View {
        NavigationView {
            List (
                apiManager.users.identified(by: \.id)
            ) { user in
                UserRow(user: user)
            }.navigationBarTitle(Text("User Information"))
        }
    }
}
